
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers  # noqa: F401
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math  # noqa: F401


@triton.jit
def epi(C, E0, O, M, N, sc, so, s0m, s0n, BLK: tl.constexpr):
    m = tl.program_id(0).to(tl.int64)
    n = tl.program_id(1) * BLK + tl.arange(0, BLK)
    mask = n < N
    acc = tl.load(C + m * sc + n, mask=mask, other=0.0).to(tl.float32)
    tmp_e0_raw = tl.load(E0 + m * s0m + n * s0n, mask=mask, other=0.0)
    tmp_e0 = tmp_e0_raw.to(tl.float32)
    tmp_x = acc.to(tl.bfloat16).to(tl.float32)
    tmp_out = tmp_x * tmp_e0
    tl.store(O + m * so + n, tmp_out, mask)
