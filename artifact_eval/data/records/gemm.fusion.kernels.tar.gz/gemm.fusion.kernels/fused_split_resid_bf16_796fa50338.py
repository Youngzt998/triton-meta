
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers  # noqa: F401
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math  # noqa: F401


@triton.jit
def combine_pre(W, C, E0, M, N, ws, wm, wn, cm, cn, e0m, e0n, S, s,
                BM: tl.constexpr, BN: tl.constexpr):
    pid = tl.program_id(0)
    npn = tl.cdiv(N, BN)
    pm = pid // npn
    pn = pid % npn
    ocm = (pm * BM + tl.arange(0, BM)).to(tl.int64)
    ocn = (pn * BN + tl.arange(0, BN)).to(tl.int64)
    mask = (ocm[:, None] < M) & (ocn[None, :] < N)
    acc = tl.zeros((BM, BN), dtype=tl.float32)
    for i in range(0, S):
        p = tl.load(W + i.to(tl.int64) * ws + ocm[:, None] * wm + ocn[None, :] * wn, mask=mask, other=0.0)
        acc = tl.where(i == 0, p, acc + p)
    acc = acc * s
    tmp_e0_raw = tl.load(E0 + ocm[:, None] * e0m + ocn[None, :] * e0n, mask=mask, other=0.0)
    tmp_e0 = tmp_e0_raw.to(tl.float32)
    tmp_x = acc.to(tl.bfloat16).to(tl.float32)
    tmp_out = tmp_x + tmp_e0
    tl.store(C + cm * ocm[:, None] + cn * ocn[None, :], tmp_out, mask=mask)


@triton.jit
def combine_gb300(W, C, E0, M, N, ws, e0m, e0n, S, s, BLK: tl.constexpr):
    m = tl.program_id(0).to(tl.int64)
    n = (tl.program_id(1) * BLK + tl.arange(0, BLK)).to(tl.int64)
    mask = n < N
    off = m * N + n
    acc = tl.zeros((BLK, ), dtype=tl.float32)
    for i in range(0, S):
        p = tl.load(W + i.to(tl.int64) * ws + off, mask=mask, other=0.0)
        acc = tl.where(i == 0, p, acc + p)
    acc = acc * s
    tmp_e0_raw = tl.load(E0 + m * e0m + n * e0n, mask=mask, other=0.0)
    tmp_e0 = tmp_e0_raw.to(tl.float32)
    tmp_x = acc.to(tl.bfloat16).to(tl.float32)
    tmp_out = tmp_x + tmp_e0
    tl.store(C + off, tmp_out, mask=mask)
