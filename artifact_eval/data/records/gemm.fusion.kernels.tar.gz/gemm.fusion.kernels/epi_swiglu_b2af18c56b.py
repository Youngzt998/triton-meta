
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers  # noqa: F401
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math  # noqa: F401


@triton.jit
def epi(C, E0, O, NEL, BLK: tl.constexpr):
    off = tl.program_id(0) * BLK + tl.arange(0, BLK)
    mask = off < NEL
    acc = tl.load(C + off, mask=mask, other=0.0).to(tl.float32)
    tmp_e0_raw = tl.load(E0 + off, mask=mask, other=0.0)
    tmp_e0 = tmp_e0_raw.to(tl.float32)
    tmp_x = acc.to(tl.bfloat16).to(tl.float32)
    tmp_g_d = 1.0 + libdevice.exp(-tmp_e0)
    tmp_g_s = libdevice.div_rn(tmp_e0, tmp_g_d).to(tl.bfloat16).to(tl.float32)
    tmp_out = tmp_g_s * tmp_x
    tl.store(O + off, tmp_out, mask)
