
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers  # noqa: F401
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math  # noqa: F401


@triton.jit
def epi(C, O, NEL, BLK: tl.constexpr):
    off = tl.program_id(0) * BLK + tl.arange(0, BLK)
    mask = off < NEL
    acc = tl.load(C + off, mask=mask, other=0.0).to(tl.float32)
    tmp_x = acc.to(tl.bfloat16).to(tl.float32)
    tmp_t = tl.where(tmp_x <= 0.0, 0.0, tmp_x).to(tl.bfloat16).to(tl.float32)
    tmp_out = tmp_t * tmp_t
    tl.store(O + off, tmp_out, mask)
