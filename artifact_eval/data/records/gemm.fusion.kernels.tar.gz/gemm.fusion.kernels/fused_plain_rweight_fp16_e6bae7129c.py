
import triton
import triton.language as tl
from torch._inductor.runtime import triton_helpers  # noqa: F401
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math  # noqa: F401


@triton.jit
def fused_pre(A, B, C, E0, M, N, K, am, ak, bk, bn, cm, cn, e0m, e0n, s,
              BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    pid = tl.program_id(0)
    npn = tl.cdiv(N, BN)
    pm = pid // npn
    pn = pid % npn
    om = ((pm * BM + tl.arange(0, BM)) % M).to(tl.int64)
    on = ((pn * BN + tl.arange(0, BN)) % N).to(tl.int64)
    ok = tl.arange(0, BK).to(tl.int64)
    ap = A + om[:, None] * am + ok[None, :] * ak
    bp = B + ok[:, None] * bk + on[None, :] * bn
    acc = tl.zeros((BM, BN), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BK)):
        acc = tl.dot(tl.load(ap, mask=ok[None, :] < K - k * BK, other=0.0),
                     tl.load(bp, mask=ok[:, None] < K - k * BK, other=0.0), acc)
        ap += BK * ak
        bp += BK * bk
    acc = acc * s
    ocm = (pm * BM + tl.arange(0, BM)).to(tl.int64)
    ocn = (pn * BN + tl.arange(0, BN)).to(tl.int64)
    mask = (ocm[:, None] < M) & (ocn[None, :] < N)
    tmp_e0_raw = tl.load(E0 + ocm[:, None] * e0m + ocn[None, :] * e0n, mask=mask, other=0.0)
    tmp_e0 = tmp_e0_raw.to(tl.float32)
    tmp_x = acc.to(tl.float16).to(tl.float32)
    tmp_out = tmp_x * tmp_e0
    tl.store(C + cm * ocm[:, None] + cn * ocn[None, :], tmp_out, mask=mask)


@triton.jit
def fused_gb300(a_desc, b_desc, c_desc, E0, M, N, K, e0m, e0n, s,
                B_NK: tl.constexpr, GROUP_M: tl.constexpr, NUM_SMS: tl.constexpr, WS: tl.constexpr,
                BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    start_pid = tl.program_id(0)
    npm = tl.cdiv(M, BM)
    npn = tl.cdiv(N, BN)
    k_tiles = tl.cdiv(K, BK)
    num_tiles = npm * npn
    per_group = GROUP_M * npn

    for tile_id in tl.range(start_pid, num_tiles, NUM_SMS, warp_specialize=WS):
        gid = tile_id // per_group
        first = gid * GROUP_M
        rows = tl.minimum(npm - first, GROUP_M)
        om = (first + (tile_id % per_group) % rows) * BM
        on = ((tile_id % per_group) // rows) * BN
        acc = tl.zeros((BM, BN), dtype=tl.float32)
        for ki in range(k_tiles):
            ok = ki * BK
            a = a_desc.load([om, ok])
            if B_NK:
                acc = tl.dot(a, b_desc.load([on, ok]).T, acc)
            else:
                acc = tl.dot(a, b_desc.load([ok, on]), acc)
        acc = acc * s
        rm = (om + tl.arange(0, BM)).to(tl.int64)
        rn = (on + tl.arange(0, BN)).to(tl.int64)
        mask = (rm[:, None] < M) & (rn[None, :] < N)
        tmp_e0_raw = tl.load(E0 + rm[:, None] * e0m + rn[None, :] * e0n, mask=mask, other=0.0)
        tmp_e0 = tmp_e0_raw.to(tl.float32)
        tmp_x = acc.to(tl.float16).to(tl.float32)
        tmp_out = tmp_x * tmp_e0
        c_desc.store([om, on], tmp_out.to(c_desc.dtype))


@triton.jit
def fused_gb300_notma(A, B, C, E0, M, N, K, am, ak, bk, bn, cm, cn, e0m, e0n, s,
                      GROUP_M: tl.constexpr, EVEN_K: tl.constexpr, I64: tl.constexpr,
                      BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    pid = tl.program_id(0)
    npm = tl.cdiv(M, BM)
    npn = tl.cdiv(N, BN)
    if GROUP_M == 1:
        pm = pid // npn
        pn = pid % npn
    else:
        per_group = GROUP_M * npn
        gid = pid // per_group
        first = gid * GROUP_M
        rows = tl.minimum(npm - first, GROUP_M)
        pm = first + (pid % per_group) % rows
        pn = (pid % per_group) // rows
    if I64:
        om = ((pm * BM + tl.arange(0, BM)) % M).to(tl.int64)
        on = ((pn * BN + tl.arange(0, BN)) % N).to(tl.int64)
        ok = tl.arange(0, BK).to(tl.int64)
    else:
        om = (pm * BM + tl.arange(0, BM)) % M
        on = (pn * BN + tl.arange(0, BN)) % N
        ok = tl.arange(0, BK)
    ap = A + om[:, None] * am + ok[None, :] * ak
    bp = B + ok[:, None] * bk + on[None, :] * bn
    acc = tl.zeros((BM, BN), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BK)):
        if EVEN_K:
            acc = tl.dot(tl.load(ap), tl.load(bp), acc)
        else:
            acc = tl.dot(tl.load(ap, mask=ok[None, :] < K - k * BK, other=0.0),
                         tl.load(bp, mask=ok[:, None] < K - k * BK, other=0.0), acc)
        ap += BK * ak
        bp += BK * bk
    acc = acc * s
    if I64:
        ocm = (pm * BM + tl.arange(0, BM)).to(tl.int64)
        ocn = (pn * BN + tl.arange(0, BN)).to(tl.int64)
    else:
        ocm = pm * BM + tl.arange(0, BM)
        ocn = pn * BN + tl.arange(0, BN)
    mask = (ocm[:, None] < M) & (ocn[None, :] < N)
    tmp_e0_raw = tl.load(E0 + ocm[:, None] * e0m + ocn[None, :] * e0n, mask=mask, other=0.0)
    tmp_e0 = tmp_e0_raw.to(tl.float32)
    tmp_x = acc.to(tl.float16).to(tl.float32)
    tmp_out = tmp_x * tmp_e0
    tl.store(C + cm * ocm[:, None] + cn * ocn[None, :], tmp_out, mask=mask)
